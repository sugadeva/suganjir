export const CONFIG = {
  API_KEY: "PTLC_xxxxxx", // Ganti dengan API Key kamu
  PANEL_URL: "https://panel.kamu.my.id", // Ganti dengan URL panel kamu
  ADMIN_PASSWORD: "adminbanget123" // Ganti dengan password admin kamu
};
